#!/usr/bin/bash
#SBATCH --mail-type=ALL
#SBATCH --nodes=1
#SBATCH --spread-job
#SBATCH --partition=namd
#SBATCH --ntasks=1
#SBATCH --time 72:00:00
#SBATCH -o slurm.%j.out
#SBATCH -e slurm.%j.err
 
mpirun -np $SLURM_NTASKS imp_sampcon exhaust -n xls_10k_run -p ../../modeling/good_scoring_models/ -d ./density_ranges.txt -m cpu_omp -c 48 -a -g 2 -gp

