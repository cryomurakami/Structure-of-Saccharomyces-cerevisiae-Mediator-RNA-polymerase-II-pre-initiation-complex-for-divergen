
"""
#############################################
##  Integrative Modeling Script
#############################################
"""
import os
import sys

import IMP
import RMF
import IMP.atom
import IMP.core
import IMP.algebra
import IMP.container
import IMP.rmf

import IMP.pmi
import IMP.pmi.tools
import IMP.pmi.topology
import IMP.pmi.samplers
import IMP.pmi.output
import IMP.pmi.dof
import IMP.pmi.macros
import IMP.pmi.restraints
import IMP.pmi.restraints.basic
import IMP.pmi.restraints.crosslinking
import IMP.pmi.restraints.em
import IMP.pmi.restraints.stereochemistry
import ihm.cross_linkers


#-------------------------------------------------------------
# Define Input Files
#-------------------------------------------------------------

datadirectory = "../data/"
topology_file = datadirectory + "topology_tail_dimer.txt"

#-------------------------------------------------------------
# Set MC Sampling Parameters
#-------------------------------------------------------------

num_frames = 10000
if '--test' in sys.argv:
    num_frames = 500
num_mc_steps = 10

#-------------------------------------------------------------
# Create movers
#-------------------------------------------------------------

# rigid body movement params
rb_max_trans = 4.00
rb_max_rot = 0.3
# flexible bead movement
bead_max_trans = 4.00
# super rigid body movement
max_srb_trans = 4.0
max_srb_rot = 0.3

#-------------------------------------------------------------
# Build the Model Representation
#-------------------------------------------------------------
# Initialize model
m = IMP.Model()

# Create list of components from topology file
topology = IMP.pmi.topology.TopologyReader(topology_file,
                                           pdb_dir=datadirectory,
                                           fasta_dir=datadirectory
                                           )
domains = topology.get_components()

bs = IMP.pmi.macros.BuildSystem(m)
bs.add_state(topology)

representation, dof = bs.execute_macro(max_rb_trans=rb_max_trans,
                                       max_rb_rot=rb_max_rot,
                                       max_bead_trans=bead_max_trans,
                                       max_srb_trans=max_srb_trans,
                                       max_srb_rot=max_srb_rot)

#-------------------------------------------------------------
# Define Degrees of Freedom
#-------------------------------------------------------------

fixed_particles=[]
for prot in [
             "Med16.0","Med14.0","Med2.0","Med3.0","Med5.0",
             "Med16.1","Med14.1","Med2.1","Med3.1","Med5.1",
             "Gal4VP16.0","Gal4VP16.1","NucleicAcidA.0","NucleicAcidB.0",
             ]:
    fixed_particles+=IMP.atom.Selection(representation,molecule=prot).get_selected_particles()

fixed_particles+=IMP.atom.Selection(representation, molecule="Med15.0", residue_indexes=range(848,1081)).get_selected_particles()
fixed_particles+=IMP.atom.Selection(representation, molecule="Med15.0", residue_indexes=range(848,1081)).get_selected_particles()

# Fix corresponding movers using dof
fixed_beads,fixed_rbs=dof.disable_movers(fixed_particles,
                                         [IMP.core.RigidBodyMover,
                                          IMP.pmi.TransformMover])

# Shuffling for random initial conformations 
IMP.pmi.tools.shuffle_configuration(representation,
                                    excluded_rigid_bodies=fixed_rbs,
                                    max_translation=50,
                                    max_rotation=50,
                                    verbose=False,
                                    cutoff=3.0,
                                    niterations=500)


# Add default mover parameters to simulation
outputobjects = []  # reporter objects (for stat files)
sampleobjects = []  # sampling objects

#-------------------------------------------------------------
# Define Scoring Function Components
#-------------------------------------------------------------

# Here we are defining a number of restraints on our system.
#  For all of them we call add_to_model() so they are incorporated into scoring
# We also add them to the outputobjects list, so they are reported in stat
# files

#-------------------------------------------------------------
# Connectivity Restraints
#-------------------------------------------------------------

moldict = bs.get_molecules()[0]
for molname in moldict:
    for mol in moldict[molname]:
        cr = IMP.pmi.restraints.stereochemistry.ConnectivityRestraint(
            mol, scale=2.0, label=molname)
        cr.add_to_model()
        cr.set_label(molname)

        outputobjects.append(cr)
        sampleobjects.append(cr)

#-------------------------------------------------------------
# Excluded Volume (evaluated at 20 residue resolution)
#-------------------------------------------------------------

ev1 = IMP.pmi.restraints.stereochemistry.ExcludedVolumeSphere(included_objects=representation,
                                                              resolution=20)
ev1.set_label('Excluded Volume')
ev1.add_to_model()
outputobjects.append(ev1)

#-------------------------------------------------------------
# XL-MS Datasets:
#-------------------------------------------------------------

# To use this restraint we have to first define the data format
# Here assuming that it's a CSV file with column names that may need to change

# Other options include the linker length and the slope for nudging
# components together

kw = IMP.pmi.io.crosslink.CrossLinkDataBaseKeywordsConverter()
# kw.set_unique_id_key("id")
kw.set_protein1_key("Protein1")
kw.set_protein2_key("Protein2")
kw.set_residue1_key("AbsPos1")
kw.set_residue2_key("AbsPos2")
# kw.set_id_score_key("Score")

# XL-MS Dataset 1

DSBU = IMP.pmi.io.crosslink.CrossLinkDataBase(kw)
DSBU.create_set_from_file(datadirectory + '../data/gal80.dsbu.IMP.csv')

x_DSBU = IMP.pmi.restraints.crosslinking.CrossLinkingMassSpectrometryRestraint(
    root_hier=representation,
    label="DSBU_XL-MS",

    database=DSBU,
    length=30,
    resolution=1.0,

    slope=0.02,
    weight=10.0,
    )

x_DSBU.add_to_model()
sampleobjects.append(x_DSBU)
outputobjects.append(x_DSBU)
dof.get_nuisances_from_restraint(x_DSBU)


#--------------------------
# Monte-Carlo Sampling
#--------------------------

# This object defines all components to be sampled as well as the sampling protocol

mc1 = IMP.pmi.macros.ReplicaExchange0(m,
                                      root_hier=representation,
                                      monte_carlo_sample_objects=dof.get_movers(),
                                      output_objects=outputobjects,
                                      crosslink_restraints=sampleobjects,
                                      monte_carlo_temperature=1.0,
                                      
                                      simulated_annealing=True,
                                      simulated_annealing_minimum_temperature=1.0,
                                      simulated_annealing_maximum_temperature=1.5,
                                      simulated_annealing_minimum_temperature_nframes=200,
                                      simulated_annealing_maximum_temperature_nframes=20,
                                      
                                      replica_exchange_minimum_temperature=1.0,
                                      replica_exchange_maximum_temperature=2.5,
                                      
                                      number_of_best_scoring_models=100,
                                      monte_carlo_steps=num_mc_steps,
                                      number_of_frames=num_frames,
                                      global_output_directory="output")

# Start Sampling
mc1.execute_macro()
