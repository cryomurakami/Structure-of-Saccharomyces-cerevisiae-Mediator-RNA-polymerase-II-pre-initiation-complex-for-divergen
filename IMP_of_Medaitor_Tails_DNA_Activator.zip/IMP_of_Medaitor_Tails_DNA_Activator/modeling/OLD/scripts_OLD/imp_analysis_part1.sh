#!/usr/bin/bash
#SBATCH --mail-type=ALL
#SBATCH --nodes=1
#SBATCH --spread-job
#SBATCH --partition=namd
#SBATCH --ntasks=1
#SBATCH --time 72:00:00
#SBATCH -o slurm.%j.out
#SBATCH -e slurm.%j.err

mpirun -np $SLURM_NTASKS imp_sampcon select_good -rd ../../modeling/ -rp xls_10k_run -sl Total_Score -pl Total_Score -alt 0.0 -aut 1000.0 -mlt 0.0 -mut 1000.0
